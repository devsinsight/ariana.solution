export interface Breadcrumb {
	title: string;
	page: string | any;
}
