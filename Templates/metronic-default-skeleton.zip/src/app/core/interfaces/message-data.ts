export interface MessageData {
	id: number;
	type: string;
	pic: string;
	username: string;
	text: string;
}
