export interface LogData {
	id: number;
	text: string;
	tags: string[];
	datetime: string;
}
