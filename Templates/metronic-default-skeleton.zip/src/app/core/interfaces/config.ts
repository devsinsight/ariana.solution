export interface ConfigModel {
	config: any;
}
