export interface Credential {
	username: string;
	email: string;
	password: string;
}
