import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'm-author-profit',
  templateUrl: './author-profit.component.html',
  styleUrls: ['./author-profit.component.scss']
})
export class AuthorProfitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
