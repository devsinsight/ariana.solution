import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'm-inner',
  templateUrl: './inner.component.html',
  styleUrls: ['./inner.component.scss']
})
export class InnerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
